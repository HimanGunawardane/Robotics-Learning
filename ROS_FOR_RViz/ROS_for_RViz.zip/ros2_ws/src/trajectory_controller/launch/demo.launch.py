from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        # Robot State Publisher – publishes TFs for all joints
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{
                'use_sim_time': False,
                'robot_description': open(
                     '/home/kimnguyen/ros2_ws/src/Wiki-GRx-Models/GRX/GR1/GR1T2/urdf/GR1T2_nohand.urdf'
                ).read()
            }],
            remappings=[('/joint_states', '/joint_states')],
        ),

        # 🎚 Joint State Publisher GUI – for manual control
        Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
            name='joint_state_publisher_gui',
            output='screen'
        ),

        # Bridge node – converts trajectory to joint states
        Node(
            package='trajectory_controller',
            executable='trajectory_to_joint_state_bridge',
            name='trajectory_to_joint_state_bridge_node',
            output='screen'
        ),

        # Trajectory controller node – sends motions
        Node(
            package='trajectory_controller',
            executable='trajectory_controller_node',
            name='trajectory_controller_node',
            output='screen'
        ),

        # RViz for visualization
        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            output='screen'
        ),
    ])

