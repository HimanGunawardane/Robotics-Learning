# File: trajectory_controller_node.py
import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
import time


class JointTrajectoryController(Node):
    def __init__(self):
        super().__init__('joint_trajectory_controller_node')
        self.get_logger().info("🤖 Joint Trajectory Controller for GR-1 started!")

        # Publisher for all joints
        self.trajectory_pub = self.create_publisher(
            JointTrajectory, '/joint_trajectory_controller/joint_trajectory', 10
        )

        # All main joints of the GR-1 humanoid
        self.joint_names = [
            # Legs
            'left_hip_pitch_joint', 'left_knee_pitch_joint', 'left_ankle_pitch_joint',
            'right_hip_pitch_joint', 'right_knee_pitch_joint', 'right_ankle_pitch_joint',
            # Waist
            'waist_pitch_joint', 'waist_roll_joint',
            # Arms
            'left_shoulder_pitch_joint', 'left_shoulder_roll_joint', 'left_elbow_pitch_joint',
            'right_shoulder_pitch_joint', 'right_shoulder_roll_joint', 'right_elbow_pitch_joint',
            # Head
            'head_yaw_joint', 'head_pitch_joint'
        ]

        self.current_positions = [0.0] * len(self.joint_names)
        self.menu()

    # --- Main interactive menu ---
    def menu(self):
        while rclpy.ok():
            action = input("Choose an action |w=wave|k=walk|s=squat|q=quit|> ").strip()
            if action == "w":
                self.wave_motion()
            elif action == "k":
                self.walk_motion()
            elif action == "s":
                self.squat_motion()
            elif action == "q":
                self.get_logger().info("👋 Exiting controller.")
                break
            else:
                print("❓ Unknown command. Try again.")

    # --- Helper: send one trajectory ---
    def send_trajectory(self, target_positions, duration=1.5):
        msg = JointTrajectory()
        msg.joint_names = self.joint_names

        point = JointTrajectoryPoint()
        point.positions = target_positions
        point.time_from_start.sec = int(duration)
        point.time_from_start.nanosec = int((duration % 1.0) * 1e9)

        msg.points.append(point)
        self.trajectory_pub.publish(msg)
        self.current_positions = target_positions
        self.get_logger().info(f"Sent trajectory over {duration:.2f}s")

    # --- Wave motion (right arm only) ---
    def wave_motion(self):
        self.get_logger().info("👋 Starting wave motion")

        pos = self.current_positions.copy()
        # Indices for right arm
        right_shoulder_pitch = self.joint_names.index('right_shoulder_pitch_joint')
        right_shoulder_roll = self.joint_names.index('right_shoulder_roll_joint')
        right_elbow_pitch = self.joint_names.index('right_elbow_pitch_joint')

        # Raise arm
        pos[right_shoulder_pitch] = -0.8
        pos[right_shoulder_roll] = 0.4
        pos[right_elbow_pitch] = -0.8
        self.send_trajectory(pos, duration=1.2)
        time.sleep(1.2)

        # Wave elbow
        for i in range(3):
            pos[right_elbow_pitch] = -0.4
            self.send_trajectory(pos, duration=0.8)
            time.sleep(0.8)
            pos[right_elbow_pitch] = -0.8
            self.send_trajectory(pos, duration=0.8)
            time.sleep(0.8)

        # Return to neutral
        self.send_trajectory([0.0] * len(self.joint_names), duration=1.5)
        self.get_logger().info("✅ Finished waving")

    # --- Squat motion (leg joints only) ---
    def squat_motion(self):
        self.get_logger().info("🧍‍♂️ Starting squat motion")
        pos = self.current_positions.copy()

        hip_pitch = [
            self.joint_names.index('left_hip_pitch_joint'),
            self.joint_names.index('right_hip_pitch_joint'),
        ]
        knee_pitch = [
            self.joint_names.index('left_knee_pitch_joint'),
            self.joint_names.index('right_knee_pitch_joint'),
        ]
        ankle_pitch = [
            self.joint_names.index('left_ankle_pitch_joint'),
            self.joint_names.index('right_ankle_pitch_joint'),
        ]

        # Squat down
        for i in hip_pitch:
            pos[i] = -0.6
        for i in knee_pitch:
            pos[i] = 1.0
        for i in ankle_pitch:
            pos[i] = -0.4

        self.send_trajectory(pos, duration=2.0)
        time.sleep(2.0)

        # Return to neutral
        self.send_trajectory([0.0] * len(self.joint_names), duration=2.0)
        self.get_logger().info("✅ Finished squat")

    # --- Walking-like leg motion (simplified alternating steps) ---
    def walk_motion(self):
        self.get_logger().info("🚶 Starting walk motion")
        pos = self.current_positions.copy()

        l_hip = self.joint_names.index('left_hip_pitch_joint')
        r_hip = self.joint_names.index('right_hip_pitch_joint')
        l_knee = self.joint_names.index('left_knee_pitch_joint')
        r_knee = self.joint_names.index('right_knee_pitch_joint')

        for step in range(3):
            pos[l_hip], pos[r_hip] = 0.5, -0.3
            pos[l_knee], pos[r_knee] = 0.8, 0.2
            self.send_trajectory(pos, duration=1.2)
            time.sleep(1.2)

            pos[l_hip], pos[r_hip] = -0.3, 0.5
            pos[l_knee], pos[r_knee] = 0.2, 0.8
            self.send_trajectory(pos, duration=1.2)
            time.sleep(1.2)

        # Return to neutral
        self.send_trajectory([0.0] * len(self.joint_names), duration=2.0)
        self.get_logger().info("✅ Finished walking")


def main(args=None):
    rclpy.init(args=args)
    controller = JointTrajectoryController()
    controller.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

