# File: trajectory_to_joint_state_bridge.py
import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory
from sensor_msgs.msg import JointState


class TrajectoryToJointStateBridge(Node):
    def __init__(self):
        super().__init__('trajectory_to_joint_state_bridge')
        self.get_logger().info("✅ Bridge node started: listening for /joint_trajectory_controller/joint_trajectory")

        # Subscribe to trajectory topic
        self.subscription = self.create_subscription(
            JointTrajectory,
            '/joint_trajectory_controller/joint_trajectory',
            self.trajectory_callback,
            10,
        )

        # Publisher to /joint_states
        self.publisher = self.create_publisher(JointState, '/joint_states', 10)
    def trajectory_callback(self, msg: JointTrajectory):
        self.get_logger().info(f"📥 Received trajectory message with {len(msg.points)} points")

        if not msg.points:
            self.get_logger().warn("⚠️ Empty trajectory message received — skipping.")
            return

        point = msg.points[-1]
        joint_state = JointState()
        joint_state.header.stamp = self.get_clock().now().to_msg()
        joint_state.name = msg.joint_names
        joint_state.position = list(point.positions)
        joint_state.velocity = []
        joint_state.effort = []

        self.publisher.publish(joint_state)
        self.get_logger().info(f"📤 Published /joint_states for {len(joint_state.name)} joints.")


def main(args=None):
    rclpy.init(args=args)
    node = TrajectoryToJointStateBridge()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

