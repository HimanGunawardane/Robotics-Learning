import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64

class SingleJointController(Node):
    def __init__(self):
        super().__init__('single_joint_controller')
        self.publisher_ = self.create_publisher(Float64, '/joint1_position_controller/commands', 10)
        self.position = 0.0
        self.menu_loop()

    def menu_loop(self):
        while rclpy.ok():
            action = input("what would you like to do? |t = test|q = quit| ")
            if action == "t":
                self.movement_test()
            elif action == "q":
                print("shutting down...")
                break
            else:
                print("Please enter a valid input")

    def movement_test(self):
        msg = Float64()
        msg.data = self.position
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing joint position: {msg.data:.2f}')
        self.position += 0.1

def main(args=None):
    rclpy.init(args=args)
    node = SingleJointController()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
