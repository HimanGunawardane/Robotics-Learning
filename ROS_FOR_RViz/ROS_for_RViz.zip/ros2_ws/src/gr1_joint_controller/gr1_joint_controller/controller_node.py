import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64

class JointController(Node):
    def __init__(self):
        super().__init__('joint_controller')
        self.joint_publishers = {
            'joint1': self.create_publisher(Float64, '/joint1_position_controller/commands', 10),
            'joint2': self.create_publisher(Float64, '/joint2_position_controller/commands', 10),
            'joint3': self.create_publisher(Float64, '/joint3_position_controller/commands', 10),
        }
        self.positions = {name: 0.0 for name in self.joint_publishers.keys()}
        self.menu_loop()

    def menu_loop(self):
        while rclpy.ok():
            action = input("what would you like to do? |t = test|q = quit| ")
            if action == "t":
                self.movement_test()
            elif action == "q":
                print("shutting down...")
                break
            else:
                print("Please enter a valid input")

    def movement_test(self):
        for joint_name, pub in self.joint_publishers.items():
            msg = Float64()
            self.positions[joint_name] += 0.1
            msg.data = self.positions[joint_name]
            pub.publish(msg)
            self.get_logger().info(f'[{joint_name}] Publishing position: {msg.data:.2f}')

        for joint_name, pub in self.joint_publishers.items():
            msg = Float64()
            self.positions[joint_name] -= 0.1
            msg.data = self.positions[joint_name]
            pub.publish(msg)
            self.get_logger().info(f'[{joint_name}] Publishing position: {msg.data:.2f}')

def main(args=None):
    rclpy.init(args=args)
    node = JointController()
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
