import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class IsaacRobotController(Node):
    def __init__(self):
        super().__init__('isaac_robot_controller')
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        self.timer = self.create_timer(0.5, self.send_command)
        self.get_logger().info('Isaac controller started — publishing Twist messages to /cmd_vel')

    def send_command(self):
        msg = Twist()
        msg.linear.x = 0.5    # move forward
        msg.angular.z = 0.0   # no rotation
        self.publisher_.publish(msg)
        self.get_logger().info(f'Published velocity: linear.x={msg.linear.x:.2f}, angular.z={msg.angular.z:.2f}')

def main(args=None):
    rclpy.init(args=args)
    node = IsaacRobotController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

