﻿To run Rviz, please run the following commands (after installed ROS2 Jazzy)

cd ros2_ws/
git clone https://github.com/FFTAI/Wiki-GRx-Models.git
colcon build
source /opt/ros/jazzy/setup.bash
source ~/ros2_ws/install/setup.bash
ros2 launch trajectory_controller demo.launch.py
