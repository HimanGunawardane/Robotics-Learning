# File: controller_node.py

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64



class JointController(Node):

    def __init__(self):
        super().__init__('joint_controller')
        
        # Create publishers for multiple joints
        self.joint_publishers = {
            #test joint publishers(not linked to any joints)
            'joint1': self.create_publisher(Float64, '/joint1_position_controller/commands', 10),
            'joint2': self.create_publisher(Float64, '/joint2_position_controller/commands', 10),
            'joint3': self.create_publisher(Float64, '/joint3_position_controller/commands', 10),
        }

        self.positions = {name: 0.0 for name in self.joint_publishers.keys()}

        
        running = True
    
        while running == True:
        
            action = input("what would you like to do? |t = test|q = quit|")
            if action == "t":
               #runs the movement test
               self.movement_test()
    
            elif action == "q":
        
              #closes the menu loop
              running = False
              print ("shutting down...")
              
              #destorys the node and shuts down ros
              joint_controller.destroy_node()
              rclpy.shutdown()
                
            else:
                print ("Please enter a valid input")
            
            
            
    #tests joint publishers
    def movement_test(self):
    
        #loops through each motor and updates its position
        for joint_name, pub in self.joint_publishers.items():
        
            #prints the name of the joint being moved next
            print(joint_name)
            
            #gets the joint's current position and increments it by 0.1
            msg = Float64()
            self.positions[joint_name] += 0.1
            
            #creates a message of the new location and publishes it
            msg.data = self.positions[joint_name]
            pub.publish(msg)
            
            #logs the joint's new published position
            self.get_logger().info(f'[{joint_name}] Publishing position: {msg.data:.2f}')
            #"joint_name" is being used an int to go through each publisher in self.joint_publishers.items()
            #a joint's actual name can be used if you want to control a specific joint E.G. self.positions["joint1"] += 0.1
            
        
        #loops through each motor and reverses everything done in the last loop
        for joint_name, pub in self.joint_publishers.items():
            msg = Float64()
            self.positions[joint_name] -= 0.1
            msg.data = self.positions[joint_name]
            pub.publish(msg)
            self.get_logger().info(f'[{joint_name}] Publishing position: {msg.data:.2f}')
        
        
        

#main method
def main(args=None):

    #initialises ros2 and the joint controller 
    rclpy.init(args=args)
    joint_controller = JointController()

    #rcply.spin loops rclpy.spin_once only runs once
    rclpy.spin_once(joint_controller)
            
    #destorys the node and shuts down ros
    joint_controller.destroy_node()
    rclpy.shutdown()
    

if __name__ == '__main__':
    main()
