# File: controller_node.py

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64



class JointController(Node):

    def __init__(self):
        super().__init__('joint_controller')
        
        # Create publisher
        self.publisher_ = self.create_publisher(Float64, '/joint1_position_controller/commands', 10) 
        self.position = 0.0
        
        running = True
    
        while running == True:
        
            action = input("what would you like to do? |t = test|q = quit|")
            if action == "t":
               #runs the movement test
               self.movement_test()
    
            elif action == "q":
        
              #closes the menu loop
              running = False
              print ("shutting down...")
              
              #destorys the node and shuts down ros
              joint_controller.destroy_node()
              rclpy.shutdown()
                
            else:
                print ("Please enter a valid input")
            
            
            
    #tests joint publishers
    def movement_test(self): msg = Float64() #get current motor position 
    msg.data = self.position 
    #logs what is happening self.publisher_.publish(msg) 
    self.get_logger().info(f'Publishing joint position: {msg.data}') 
    #updates the motor position 
    self.position += 0.1
        
        
        

#main method
def main(args=None):

    #initialises ros2 and the joint controller 
    rclpy.init(args=args)
    joint_controller = JointController()

    #rcply.spin loops rclpy.spin_once only runs once
    rclpy.spin_once(joint_controller)
            
    #destorys the node and shuts down ros
    joint_controller.destroy_node()
    rclpy.shutdown()
    

if __name__ == '__main__':
    main()
