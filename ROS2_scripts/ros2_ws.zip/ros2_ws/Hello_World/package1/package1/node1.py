def main():

    running = true
    
    while running == true:
    
        action = input('Control inputs: |w|l|r|b|h|  |q|to quit')
        
        if action == "w":
            print("robot walked 1 meter forwards")
        elif action == "b":
            print("robot walked 1 meter backwards")
        elif action == "l":
            print("robot turned to the left")
        elif action == "r":
            print("robot turned to the right")
        elif action == "h":
            print("robot waved hello")
        elif action == "q":
            print("shutting down...")
            running = false
        else:
            print("input not recognised, please try again")


if __name__ == '__main__':
    main()
